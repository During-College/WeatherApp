const pgp = require('pg-promise')();
//We have to set ssl usage to true for Heroku to accept our connection
pgp.pg.defaults.ssl = true;

//Create connection to Heroku Database
const db = pgp('postgres://njgewrwqleoccf:0f64bef081d66cd369249e00b77f4ceb6d9e5b7df0f7eb783f523ab63fc7b825@ec2-23-23-180-121.compute-1.amazonaws.com:5432/d7ermsgtmmsgrl');

if(!db) {
   console.log("SHAME! Follow the intructions and set your DATABASE_URL correctly");
   process.exit(1);
}

module.exports = db;

