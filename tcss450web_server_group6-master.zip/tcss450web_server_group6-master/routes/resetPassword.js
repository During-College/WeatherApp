//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();

const bodyParser = require("body-parser");
//This allows parsing of the body of POST requests, that are encoded in JSON
app.use(bodyParser.json());

//We use this create the SHA256 hash
const crypto = require("crypto");

//Create connection to Heroku Database
let db = require('../utilities/utils').db;

let getHash = require('../utilities/utils').getHash;

let sendEmail = require('../utilities/utils').sendEmail;

//var formidable = require('formidable');

var router = express.Router();

router.post('/resetPassword', (req, res)=> {
    let email = req.body['email'];
    let link = crypto.randomBytes(20).toString('hex');
    db.one(`SELECT email FROM Members WHERE (verified=1 AND email=$1);`, email).then(result=>{
        db.none(`UPDATE Members SET verification=$1 WHERE email=$2;`, [link, result.email]).then(()=>{
            res.send({
                success: true
            });
            sendEmail("cfb3@uw.edu", email, "Password Reset Link for UWT Chat", "http://tcss450-group-6.herokuapp.com/reset?link=" + link);
        });
    }).catch(err=>{
        res.send({
            success: false,
            error: err
        })
    });
});

router.get(`/reset`, (req, res)=> {
    let link = req.query['link'];
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write('<form action="newPassword" method="get">');
    res.write('<input type="hidden" value="'+link+'" name="link">');
    res.write('Enter new password: ');
    res.write('<input type="password" name="password1"><br>');
    res.write('Repeat new Password: ');
    res.write('<input type="password" name="password2"><br>');
    res.write('<input type="submit" value="Submit">');
    res.write('</form>');
  return res.end();
});

router.get('/newPassword', (req, res)=> {
    let link = req.query['link'];
    let pw1 = req.query['password1'];
    let pw2 = req.query['password2'];
   // console.log('Here1');
    if(pw2 !== pw1)
    {
       // console.log('Here2');
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write('<form action="newPassword" method="get">');
        res.write('<input type="hidden" value="'+link+'" name="link">');
        res.write('Passwords did not match!<br>');
        res.write('Enter new password: ');
        res.write('<input type="password" name="password1"><br>');
        res.write('Repeat new Password: ');
        res.write('<input type="password" name="password2"><br>');
        res.write('<input type="submit" value="Submit">');
        res.write('</form>');  
        return res.end();      
    }
    else
    {
        let salt = crypto.randomBytes(32).toString("hex");
        let salted_hash = getHash(pw1, salt);
        //console.log('Here3');
        //console.log(req.body.password1);
        //console.log(pw1);
        db.none('UPDATE Members SET salt=$1, password=$2 WHERE verification=$3;', [salt, salted_hash, link]).then(()=>{
            res.write('Password updated succesfully!');
            return res.end();
        })
    }
});

module.exports = router;