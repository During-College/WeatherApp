//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();

var crypto = require("crypto");

//Create connection to Heroku Database
let db = require('../utilities/utils').db;
var router = express.Router();

function getChats(username)
{
   // console.log("Actually in getChats")
    let query = `SELECT ChatID FROM Chatmembers INNER JOIN Members ON chatmembers.MemberID=Members.MemberID WHERE Username=$1`
    return db.task(t => {
        //console.log("In task")
        return t.map(query, username, aChat => {
            let query = `SELECT Members.Username from ChatMembers INNER JOIN
                Members ON ChatMembers.MemberID=Members.MemberID WHERE ChatID=$1`
           // console.log("In map")
            return t.manyOrNone(query, aChat.chatid)
                    .then(names => {
                        //console.log("In innermost then bloc")
                        //console.log(names)
                        aChat.members = names;
                        return aChat;
                    });
        }).then(t.batch);
    });
}

function startChat(members,starter)
{
    let chatid;
    return db.task(t=> {
        let insert = `INSERT INTO Chats(Name) VALUES($1);`;
        
        let name = crypto.randomBytes(20).toString('hex');
        return db.none(insert,name).then(()=> {
           // console.log("Inserting chat")
            return db.one('SELECT ChatID from Chats WHERE name=$1;', name).then(result => {
               // console.log("Retrieving chatid")
                chatid=result.chatid;
                //console.log(chatid)
               // console.log(members)
                return members.forEach(element => {
                   // console.log(element)
                    db.one(`SELECT MemberID from Members where Username=$1;`, element).then(mem=>{
                        //console.log(mem.memberid)
                       // console.log(result.chatid)
                        db.none(`INSERT INTO ChatMembers(ChatID, MemberID) VALUES($1,$2);`, [result.chatid, mem.memberid]).then(()=> {
                            if(element != starter)
                                return db.none(`INSERT INTO Notifications(MemberID,Sender,Message,ChatID) VALUES($1, $2, $3, $4);`,
                                                 [mem.memberid, starter, starter+` started a chat session with you!`, chatid]);
                        });
                    })
                });
            });
        })
    }).then(()=> {
        return chatid;
    })
}

function deleteChat(theUsername, theChatID)
{
    return db.task(t => {
        return db.one(`SELECT memberID from Members WHERE Username=$1;`, theUsername).then(result=> {
            return db.none(`DELETE FROM ChatMembers WHERE ChatID=$1 AND MemberID=$2;`, [theChatID, result.memberid])
            .then(()=> {
                return db.manyOrNone(`SELECT * FROM ChatMembers WHERE ChatID=$1`, theChatID).then(mems=> {
                    if(mems.length<2)
                        return db.none(`INSERT INTO Messages(ChatID, Message, MemberID) VALUES($1, $2, $3);`,
                            [theChatID, theUsername+` has left the conversation. Chat session will now end`,
                             result.memberid]);
                    else
                        return db.none(`INSERT INTO Messages(ChatID, Message, MemberID) VALUES($1, $2, $3);`,
                        [theChatID, theUsername+` has left the conversation.`, result.memberid]);
                });
            });
        });
    });
}

router.get("/getChats", (req, res) => {
   // console.log("In getChats");
    let username = req.query['username'];
    getChats(username).then(chats => res.send({
        success:true,
        chats:chats
    })).catch(error => {
        console.log(error)
        res.send({
            success:false,
            error:error
        })});
});

router.post("/startChat", (req, res) => {
    let username = req.body['username'];
    let members = req.body['members'];
    if (!username || !members) {
        res.send({
            success: false,
            error: "Username or members not supplied"
        });
        return;
    }
    //TODO check if username has been verified, etc
    startChat(members, username).then(chatid => res.send({
        success:true,
        chatid:chatid
    })).catch(error => {
        console.log(error)
        res.send({
            success:false,
            error:error
        })})
});

router.post("/deleteChat", (req, res) => {
    let username = req.body['username'];
    let chatid = req.body['chatid'];
    if (!username || !chatid) {
        res.send({
            success: false,
            error: "Username or chatid not supplied"
        });
        return;
    }
    //console.log(chatid)
    //console.log(username)
    deleteChat(username, chatid).then(()=> res.send({
        success:true
    })).catch(error => {
        console.log(error)
        res.send({
            success:false,
            error:error
        })});
});
module.exports = router;