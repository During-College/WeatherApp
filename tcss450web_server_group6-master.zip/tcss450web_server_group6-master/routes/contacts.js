//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();

const bodyParser = require("body-parser");
//This allows parsing of the body of POST requests, that are encoded in JSON
app.use(bodyParser.json());
//Create connection to Heroku Database
let db = require('../utilities/utils').db;
var router = express.Router();


// router.get("/getContacts", (req, res) => {
//     let memberid_a = req.query['memberid_a'];
//     let memberid_b = req.query['memberid_b'];
//     let query = `SELECT memberid_b FROM Contacts WHERE verified = 1`
//     db.manyOrNone(query, [memberid_b])
//         .then((rows) => {
//             res.send({
//                 contacts: rows
//             })
//         }).catch((err) => {
//             res.send({
//                 success: false,
//                 error: err
//             })
//         });
// });

router.get("/getContacts", (req, res) => {

    db.manyOrNone('SELECT memberid_b FROM Contacts')
    //If successful, run function passed into .then()
    .then((data) => {
        res.send({
            success: true,
            contacts: data
        });
    }).catch((error) => {
        console.log(error);
        res.send({
            success: false,
            error: error
        })
    });
});

module.exports = router;