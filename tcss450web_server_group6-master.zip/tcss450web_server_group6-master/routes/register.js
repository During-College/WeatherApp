//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();

const bodyParser = require("body-parser");
//This allows parsing of the body of POST requests, that are encoded in JSON
app.use(bodyParser.json());

//We use this create the SHA256 hash
const crypto = require("crypto");

//Create connection to Heroku Database
let db = require('../utilities/utils').db;

let getHash = require('../utilities/utils').getHash;

let sendEmail = require('../utilities/utils').sendEmail;

var router = express.Router();

router.post('/register', (req, res) => {
    res.type("application/json");

    //Retrieve data from query params
    var first = req.body['first'];
    var last = req.body['last'];
    var username = req.body['username'];
    var email = req.body['email'];
    var password = req.body['password'];
    //Verify that the caller supplied all the parameters
    //In js, empty strings or null values evaluate to false
    if(first && last && username && email && password) {

        if(username.includes(' '))
            return res.send({
                success:false,
                error: 'Username cannot contain spaces'
            });

        if(password.length < 6)
        return res.send({
            success:false,
            error: 'Password must be 6 characters or longer'
        });

        if(/\d/.test(password)===false || /[a-zA-Z]/.test(password)===false)
        return res.send({
            success:false,
            error: 'Password must contain at least one number and letter.'
        });
        //We're storing salted hashes to make our application more secure
        //If you're interested as to what that is, and why we should use it
        //watch this youtube video: https://www.youtube.com/watch?v=8ZtInClXe1Q
        let salt = crypto.randomBytes(32).toString("hex");
        let salted_hash = getHash(password, salt);
        
        //Use .none() since no result gets returned from an INSERT in SQL
        //We're using placeholders ($1, $2, $3) in the SQL query string to avoid SQL Injection
        //If you want to read more: https://stackoverflow.com/a/8265319
        let link = crypto.randomBytes(20).toString('hex');
        let params = [first, last, username, email, salted_hash, salt, link];
        db.none("INSERT INTO MEMBERS(FirstName, LastName, Username, Email, Password, Salt, Verification) VALUES ($1, $2, $3, $4, $5, $6, $7)", params)
        .then(() => {
            //We successfully added the user, let the user know
            res.send({
                success: true
            });
            sendEmail("cfb3@uw.edu", email, "Welcome!", "http://tcss450-group-6.herokuapp.com/verify?link=" + link);
        }).catch((err) => {
            //log the error
            console.log(err);
            //If we get an error, it most likely means the account already exists
            //Therefore, let the requester know they tried to create an account that already exists
            res.send({
                success: false,
                error: err
            });
        });
    } else {
        res.send({
            success: false,
            input: req.body,
            error: "Missing required user information"
        });
    }
});

router.get("/verify", (req,res)=> {
    let link = req.query['link'];
    let query = `UPDATE members SET verified=1 WHERE verification=$1;`;
    db.none(query, link).then(()=>{
        res.send('Verified. Please return to the app to login.');
    }).catch(err=>{
        res.send('Error: ' + err);
    });
});

module.exports = router;

