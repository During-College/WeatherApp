//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();
//Create connection to Heroku Database
let db = require('../utilities/utils').db;
var router = express.Router();

router.get("/getNotifications", (req, res) => {
    let theusername = req.query['username'];
    let type = req.query['type'];
    if (type == "message") {
        let query = `SELECT *
                    FROM NotificationsMessages
                    WHERE username=$1`;
        db.manyOrNone(query, [theusername])
            .then((rows) => {
                
                let remove = `DELETE FROM NotificationsMessages WHERE username=$1`
                db.manyOrNone(remove, [theusername]);
                
                res.send({
                    notifications: rows
                })
            }).catch((err) => {
                res.send({
                    success: false,
                    error: err
                })
            })
    } else if (type == "something else") {

    }
});

router.get("/getUnreadNotifications", (req, res) => {
    let username = req.query[`username`];
    let idquery = `SELECT memberID FROM Members WHERE username=$1;`;
    let note = `SELECT primarykey,sender,message,chatid,to_char(timestamp AT TIME ZONE 'PDT', 
                    'YYYY-MM-DD HH24:MI:SS.US') AS timestamp from Notifications 
                    WHERE(memberID=$1 AND read=0) ORDER BY Timestamp DESC;`;
    db.task(t=>{
        db.one(idquery, username).then(result=>{
            db.manyOrNone(note, result.memberid).then(rows=>{
                res.send({
                    success:true,
                    notifications: rows
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

router.post("/markNotificationRead", (req,res)=>{
    let username = req.body['username'];
    let sender = req.body['sender'];
    let key = req.body['primarykey'];
    let memq = `SELECT memberid from Members WHERE username=$1;`;
    let query = `UPDATE Notifications SET read=1 WHERE(memberID=$1 AND
                    sender=$2 AND primarykey=$3);`;
    db.task(t=>{
        db.one(memq, username).then(result=>{
            db.none(query, [result.memberid, sender, key]).then(()=>{
                res.send({
                    success:true
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

module.exports = router;