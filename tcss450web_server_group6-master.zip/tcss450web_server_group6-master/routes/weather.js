//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();
//Create connection to Heroku Database
let db = require('../utilities/utils').db;
var router = express.Router();

router.get("/getLocations", (req, res) => {
    let name = req.query['name'];
    let query = `SELECT *
                FROM SavedLocations
                WHERE name=$1`;
    db.manyOrNone(query, [name])
        .then((rows) => {            
            res.send({
                locations: rows
            })
        }).catch((err) => {
            res.send({
                success: false,
                error: err
            })
        })
});

router.post("/addLocation", (req, res) => {
    let name = req.body['name'];
    let location = req.body['location'];
    let insert = `INSERT INTO SavedLocations(Name, Location)
 SELECT $1, $2`
    db.none(insert, [name, location])
        .then(() => {
            let query = `SELECT *
                        FROM SavedLocations
                        WHERE name=$1`;
            db.manyOrNone(query, [name])
                .then((rows) => {            
                    res.send({
                        locations: rows
                    })
                }).catch((err) => {
                    res.send({
                        success: false,
                        error: err
                    })
                })
        })
});

router.post("/removeLocation", (req, res) => {
    let name = req.body['name'];
    let location = req.body['location'];
    let remove = `DELETE FROM SavedLocations WHERE name=$1 AND location=$2`
    db.manyOrNone(remove, [name, location])
        .then(() => {
            let query = `SELECT *
                        FROM SavedLocations
                        WHERE name=$1`;
            db.manyOrNone(query, [name])
                .then((rows) => {            
                    res.send({
                        locations: rows
                    })
                }).catch((err) => {
                    res.send({
                        success: false,
                        error: err
                    })
                })
        })
});

module.exports = router;