//express is the framework we're going to use to handle requests
const express = require('express');
//Create a new instance of express
const app = express();
//Create connection to Heroku Database
let db = require('../utilities/utils').db;
var router = express.Router();


router.get("/getConnections", (req, res)=> {
    let username = req.query['username'];
    let query = `SELECT memberid FROM Members WHERE username=$1;`;
    let secondQuery = `SELECT username,firstname,lastname
    FROM Contacts INNER JOIN Members 
        ON Contacts.memberID_A=Members.MemberID
        OR Contacts.memberID_B=Members.MemberID
    WHERE (MemberID_A=$1 OR MemberID_B=$1)
    AND Contacts.verified=1 AND username!=$2;`;

    db.task(t=> {
        return db.one(query, username).then(result=> {
            return db.manyOrNone(secondQuery, [result.memberid, username]).then(conns=> {
                res.send({
                    success:true,
                    connections:conns
                });
            });
        });
    }).catch(err=> {
        res.send({
            success:false,
            error:err
        })
    });
});

router.post("/searchConnections", (req, res)=> {
    let username = req.body['username'];
    let search = req.body['search'];
    let query = `SELECT memberid FROM Members WHERE username=$1;`;
    let secondQuery = `SELECT username,firstname,lastname from Members
                       LEFT JOIN Contacts 
                        ON Contacts.memberID_A=Members.MemberID
                        OR Contacts.memberID_B=Members.MemberID
                       WHERE (username LIKE $1 OR firstname LIKE $1
                       OR lastname LIKE $1)
                       AND username!=$2 
                       EXCEPT (select username,firstname,lastname from Contacts INNER JOIN Members 
                        ON Contacts.memberID_A=Members.MemberID OR Contacts.MemberID_B=Members.MemberID 
                        WHERE MemberID_A='$3' OR MemberID_B='$3');`;

    db.task(t=> {
        return db.one(query, username).then(result=> {
            return db.manyOrNone(secondQuery, ['%'+search+'%', username, result.memberid]).then(pots=> {
                res.send({
                    success:true,
                    connections: pots
                });
            });
        });
    }).catch(err=>{
        console.log(err);
        res.send({
            success:false,
            error:err
        });
    });
});

router.get("/getSentConnections", (req,res)=>{
    let username = req.query['username'];
    let query = `SELECT memberid FROM Members WHERE username=$1;`;
    let secondQuery = `SELECT username,firstname,lastname FROM Contacts 
                        INNER JOIN Members ON Contacts.memberID_A=Members.memberID 
                        OR Contacts.memberID_B=Members.memberID 
                        WHERE Contacts.memberID_A=$1 AND Contacts.verified!=1
                        AND username!=$2;`;

    db.task(t=>{
        return db.one(query,username).then(result=>{
            return db.manyOrNone(secondQuery,[result.memberid,username]).then(conns=>{
                res.send({
                    success:true,
                    connections:conns
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

router.get("/getReceivedConnections", (req,res)=>{
    let username = req.query['username'];
    let query = `SELECT memberid FROM Members WHERE username=$1;`;
    let secondQuery = `SELECT username,firstname,lastname FROM Contacts 
                        INNER JOIN Members ON Contacts.memberID_A=Members.memberID 
                        OR Contacts.memberID_B=Members.memberID 
                        WHERE Contacts.memberID_B=$1 AND Contacts.verified!=1
                        AND username!=$2;`;
    let note = `DELETE FROM Notifications WHERE (memberid=$1 AND chatid='connection');`;

    db.task(t=>{
        return db.one(query,username).then(result=>{
            return db.manyOrNone(secondQuery,[result.memberid,username]).then(conns=>{
                db.none(note, result.memberid);
                res.send({
                    success:true,
                    connections:conns
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

router.post("/addConnection", (req,res)=>{
    let username = req.body['username'];
    let connection = req.body['connection'];
    let query = `SELECT memberID FROM Members WHERE username=$1;`;
    let secondQuery = `INSERT INTO Contacts(memberID_A,memberID_B,verified) VALUES($1,$2,0);`;
    let note = `INSERT INTO Notifications(MemberID,Sender,Message, ChatID) VALUES($1, $2, $3, $4);`;

    db.task(t=>{
        return db.one(query,username).then(me=>{
            return db.one(query,connection).then(friend=>{
                return db.none(secondQuery,[me.memberid,friend.memberid]).then(()=>{
                    return db.none(note, [friend.memberid, username, username + ` sent a connection request`, 'connection']).then(()=>{
                        res.send({
                            success:true
                        });
                    });
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

router.post("/removeConnection", (req,res)=>{
    let username = req.body['username'];
    let connection = req.body['connection'];
    let query = `SELECT memberID FROM Members WHERE username=$1;`;
    let secondQuery = `DELETE FROM Contacts WHERE (memberID_A=$1 AND memberID_B=$2)
                        OR (memberID_B=$1 AND memberID_A=$2);`;

    db.task(t=>{
        return db.one(query,username).then(me=>{
            return db.one(query,connection).then(friend=>{
                return db.none(secondQuery,[me.memberid,friend.memberid]).then(()=>{
                    res.send({
                        success:true
                    });
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

router.post("/approveConnection", (req,res)=>{
    let username = req.body['username'];
    let connection = req.body['connection'];
    let query = `SELECT memberID FROM Members WHERE username=$1;`;
    let secondQuery = `UPDATE Contacts SET verified=1 
                        WHERE (Contacts.memberID_A=$2 AND Contacts.memberID_B=$1);`;

    db.task(t=>{
        return db.one(query,username).then(me=>{
            return db.one(query,connection).then(friend=>{
                return db.none(secondQuery,[me.memberid,friend.memberid]).then(()=>{
                    res.send({
                        success:true
                    });
                });
            });
        });
    }).catch(err=>{
        res.send({
            success:false,
            error:err
        });
    });
});

module.exports = router;